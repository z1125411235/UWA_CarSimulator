# CarSimulator
A Top Down 2D Car Simulator For Unity

![Screenshot](http://i.imgur.com/m2yvTgK.jpg)

Try the demo: 

http://www.jgallant.com/CarSim/


Article that details all of the physics involved:

http://www.asawicki.info/Mirror/Car%20Physics%20for%20Games/Car%20Physics%20for%20Games.html


Source code references:

https://github.com/spacejack/carphysics2d
